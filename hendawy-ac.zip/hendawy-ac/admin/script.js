// Initialize Admin Dashboard
document.addEventListener('DOMContentLoaded', function () {
    initTabs();
    loadDashboard();
});

// Tabs functionality
function initTabs() {
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const targetTab = btn.dataset.tab;

            tabBtns.forEach(b => b.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));

            btn.classList.add('active');
            document.getElementById(targetTab).classList.add('active');

            // Load data for active tab
            if (targetTab === 'bookings') loadBookings();
            if (targetTab === 'slots') loadSlots();
            if (targetTab === 'products') loadProducts();
        });
    });
}

// Dashboard Stats
async function loadDashboard() {
    try {
        const response = await fetch('/api/bookings');
        const bookings = await response.json();

        const today = new Date().toISOString().split('T')[0];
        const todayBookings = bookings.filter(b => b.date === today);

        document.getElementById('totalBookings').textContent = bookings.length;
        document.getElementById('todayBookings').textContent = todayBookings.length;
        document.getElementById('pendingBookings').textContent =
            bookings.filter(b => b.status === 'Pending').length;
    } catch (error) {
        console.error('Error loading dashboard:', error);
    }
}

// Bookings Management
async function loadBookings() {
    try {
        const response = await fetch('/api/bookings');
        const bookings = await response.json();

        const tbody = document.getElementById('bookingsTable');
        tbody.innerHTML = '';

        bookings.forEach(booking => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${booking.name}</td>
                <td><a href="tel:${booking.phone}">${booking.phone}</a></td>
                <td>${booking.date}</td>
                <td>${booking.time}</td>
                <td><span class="status ${booking.status.toLowerCase()}">${booking.status}</span></td>
                <td>
                    <select onchange="updateBookingStatus('${booking._id}', this.value)" class="action-btn">
                        <option value="Pending" ${booking.status === 'Pending' ? 'selected' : ''}>معلق</option>
                        <option value="Confirmed" ${booking.status === 'Confirmed' ? 'selected' : ''}>مؤكد</option>
                        <option value="Completed" ${booking.status === 'Completed' ? 'selected' : ''}>مكتمل</option>
                        <option value="Cancelled" ${booking.status === 'Cancelled' ? 'selected' : ''}>ملغي</option>
                    </select>
                </td>
            `;
            tbody.appendChild(row);
        });
    } catch (error) {
        console.error('Error loading bookings:', error);
    }
}

async function updateBookingStatus(id, status) {
    try {
        await fetch(`/api/bookings/${id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status })
        });
        loadDashboard(); // Refresh stats
    } catch (error) {
        alert('خطأ في تحديث الحالة');
    }
}

// Slots Management
async function loadSlots() {
    try {
        const response = await fetch('/api/slots');
        const slots = await response.json();

        const tbody = document.getElementById('slotsTable');
        tbody.innerHTML = '';

        slots.forEach(slot => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${slot.date}</td>
                <td>${slot.time}</td>
                <td>${slot.isAvailable ? '✅ متاح' : '❌ محجوز'}</td>
                <td>
                    <button class="action-btn btn-success" onclick="toggleSlot('${slot._id}', ${slot.isAvailable})">
                        ${slot.isAvailable ? 'حجز' : 'إفراغ'}
                    </button>
                </td>
            `;
            tbody.appendChild(row);
        });
    } catch (error) {
        console.error('Error loading slots:', error);
    }
}

async function addSlot() {
    const date = document.getElementById('slotDate').value;
    const time = document.getElementById('slotTime').value;

    if (!date || !time) {
        alert('يرجى ملء جميع الحقول');
        return;
    }

    try {
        await fetch('/api/slots', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify([{ date, time, isAvailable: true }])
        });
        loadSlots();
        document.getElementById('slotDate').value = '';
        document.getElementById('slotTime').value = '';
    } catch (error) {
        alert('خطأ في إضافة الوقت');
    }
}

async function toggleSlot(id, isAvailable) {
    try {
        await fetch(`/api/slots/${id}`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ isAvailable: !isAvailable })
        });
        loadSlots();
    } catch (error) {
        alert('خطأ في تحديث الوقت');
    }
}

// Products Management - الجديد كامل
async function loadProducts() {
    try {
        const response = await fetch('http://localhost:3000/api/products');
        const products = await response.json();

        const grid = document.getElementById('productsGrid');
        grid.innerHTML = '';

        products.forEach(product => {
            const card = document.createElement('div');
            card.className = 'product-card';
            card.innerHTML = `
                <div class="product-image-container">
                    <img src="http://localhost:3000${product.image}" 
                         alt="${product.title}" class="product-image" 
                         onerror="this.src='https://via.placeholder.com/300x150?text=عرض'">
                    <div class="product-actions">
                        <button class="action-btn btn-primary" onclick="editProduct('${product._id}')">تعديل</button>
                        <button class="action-btn btn-danger" onclick="deleteProduct('${product._id}')">حذف</button>
                    </div>
                </div>
                <h4>${product.title}</h4>
                <div class="product-price">${product.price} جنيه</div>
                <p>${product.description || ''}</p>
                
                <!-- Edit Form -->
                <form class="product-edit-form" id="editForm-${product._id}" enctype="multipart/form-data">
                    <div class="form-row">
                        <input type="text" name="title" value="${product.title}" required>
                        <input type="number" name="price" value="${product.price}" required>
                    </div>
                    <input type="file" name="image" accept="image/*">
                    <textarea name="description">${product.description || ''}</textarea>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">حفظ التعديلات</button>
                        <button type="button" class="btn btn-secondary" onclick="cancelEdit('${product._id}')">إلغاء</button>
                    </div>
                </form>
            `;
            grid.appendChild(card);
        });
    } catch (error) {
        console.error('Error loading products:', error);
    }
}

// Add New Product
document.getElementById('productForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append('title', document.getElementById('productTitle').value);
    formData.append('price', document.getElementById('productPrice').value);
    formData.append('description', document.getElementById('productDesc').value);
    formData.append('image', document.getElementById('productImage').files[0]);

    try {
        const response = await fetch('http://localhost:3000/api/products', {
            method: 'POST',
            body: formData
        });

        if (response.ok) {
            loadProducts();
            e.target.reset();
            alert('✅ تم إضافة العرض بنجاح');
        }
    } catch (error) {
        alert('❌ خطأ في إضافة العرض');
    }
});

// Edit Product
function editProduct(id) {
    document.querySelectorAll('.product-edit-form').forEach(form => {
        form.classList.remove('active');
    });
    document.getElementById(`editForm-${id}`).classList.add('active');
}

// Cancel Edit
function cancelEdit(id) {
    document.getElementById(`editForm-${id}`).classList.remove('active');
}

// Update Product
document.addEventListener('submit', async (e) => {
    if (e.target.classList.contains('product-edit-form')) {
        e.preventDefault();

        const formData = new FormData(e.target);
        const id = e.target.id.split('-')[1];

        try {
            const response = await fetch(`http://localhost:3000/api/products/${id}`, {
                method: 'PATCH',
                body: formData
            });

            if (response.ok) {
                loadProducts();
                alert('✅ تم حفظ التعديلات');
            }
        } catch (error) {
            alert('❌ خطأ في حفظ التعديلات');
        }
    }
});

async function deleteProduct(id) {
    if (confirm('هل أنت متأكد من حذف هذا العرض؟')) {
        try {
            await fetch(`http://localhost:3000/api/products/${id}`, {
                method: 'DELETE'
            });
            loadProducts();
            alert('✅ تم الحذف بنجاح');
        } catch (error) {
            alert('❌ خطأ في الحذف');
        }
    }
}
async function deleteProduct(id) {
    if (confirm('هل أنت متأكد من الحذف؟')) {
        try {
            await fetch(`/api/products/${id}`, { method: 'DELETE' });
            loadProducts();
        } catch (error) {
            alert('خطأ في الحذف');
        }
    }
}

// Excel Export
document.getElementById('exportBtn').addEventListener('click', function (e) {
    e.preventDefault();
    window.open('/api/export', '_blank');
});