// Language & Direction Management
const translations = {
    ar: {
        home: 'الرئيسية',
        booking: 'حجز',
        services: 'الخدمات',
        offers: 'العروض',
        contact: 'تواصل',
        heroTitle: 'تبريد منزلك بأفضل الأسعار',
        heroSubtitle: 'خدمة صيانة وتركيب تكييف سريعة وموثوقة',
        bookNow: 'احجز الآن',
        callNow: 'اتصل الآن',
        name: 'الاسم',
        phone: 'رقم الهاتف',
        address: 'العنوان',
        acType: 'نوع التكييف',
        date: 'التاريخ',
        time: 'وقت الموعد',
        servicesTitle: 'خدماتنا',
        maintenance: 'صيانة دورية',
        installation: 'تركيب تكييف',
        diagnosis: 'تشخيص أعطال',
        offersTitle: 'عروضنا الحالية',
        contactTitle: 'تواصل معنا',
        phoneLabel: 'هاتف',
        addressLabel: 'العنوان',
        success: '✅ تم الحجز بنجاح! سنتصل بك قريباً'
    },
    en: {
        home: 'Home',
        booking: 'Booking',
        services: 'Services',
        offers: 'Offers',
        contact: 'Contact',
        heroTitle: 'Cool Your Home at Best Prices',
        heroSubtitle: 'Fast and reliable AC maintenance and installation service',
        bookNow: 'Book Now',
        callNow: 'Call Now',
        name: 'Name',
        phone: 'Phone',
        address: 'Address',
        acType: 'AC Type',
        date: 'Date',
        time: 'Time',
        servicesTitle: 'Our Services',
        maintenance: 'Periodic Maintenance',
        installation: 'AC Installation',
        diagnosis: 'Fault Diagnosis',
        offersTitle: 'Current Offers',
        contactTitle: 'Contact Us',
        phoneLabel: 'Phone',
        addressLabel: 'Address',
        success: '✅ Booking successful! We will contact you soon'
    }
};

let currentLang = 'ar';

// Initialize app
document.addEventListener('DOMContentLoaded', function () {
    initLanguage();
    initNavbar();
    initDatePicker();
    initForm();
    loadOffers();
    loadTimeSlots();
});

// Language Toggle
document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.addEventListener('click', function () {
        currentLang = this.dataset.lang;
        document.documentElement.lang = currentLang;
        document.documentElement.dir = currentLang === 'ar' ? 'rtl' : 'ltr';

        document.querySelectorAll('.lang-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');

        updateLanguage();
    });
});

function initLanguage() {
    updateLanguage();
}

function updateLanguage() {
    const t = translations[currentLang];
    document.querySelector('#hero .hero-title').textContent = t.heroTitle;
    document.querySelector('#hero .hero-subtitle').textContent = t.heroSubtitle;
    document.querySelector('[onclick="scrollToBooking()"]').textContent = t.bookNow;
    document.querySelector('.btn-secondary').textContent = t.callNow;

    // Update nav
    document.querySelectorAll('.nav-link')[0].textContent = t.home;
    document.querySelectorAll('.nav-link')[1].textContent = t.booking;
    document.querySelectorAll('.nav-link')[2].textContent = t.services;
    document.querySelectorAll('.nav-link')[3].textContent = t.offers;
    document.querySelectorAll('.nav-link')[4].textContent = t.contact;

    // Form labels
    document.querySelector('#name').previousElementSibling.textContent = t.name;
    document.querySelector('#phone').previousElementSibling.textContent = t.phone;
    document.querySelector('#address').previousElementSibling.textContent = t.address;
    document.querySelector('#acType').previousElementSibling.textContent = t.acType;
    document.querySelector('#date').previousElementSibling.textContent = t.date;
    document.querySelector('#time').previousElementSibling.textContent = t.time;

    // Sections
    document.querySelectorAll('.section-title')[0].textContent = t.booking;
    document.querySelectorAll('.section-title')[1].textContent = t.servicesTitle;
    document.querySelectorAll('.section-title')[2].textContent = t.offersTitle;
    document.querySelectorAll('.section-title')[3].textContent = t.contactTitle;

    // Services
    document.querySelectorAll('.service-card h3')[0].textContent = t.maintenance;
    document.querySelectorAll('.service-card h3')[1].textContent = t.installation;
    document.querySelectorAll('.service-card h3')[2].textContent = t.diagnosis;

    // Success message
    document.querySelector('#successMessage').textContent = t.success;
}

// Navigation
function initNavbar() {
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');

    hamburger.addEventListener('click', () => {
        hamburger.classList.toggle('active');
        navMenu.classList.toggle('active');
    });

    // Close menu on link click
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', () => {
            hamburger.classList.remove('active');
            navMenu.classList.remove('active');
        });
    });

    // Sticky navbar
    window.addEventListener('scroll', () => {
        const navbar = document.querySelector('.navbar');
        if (window.scrollY > 100) {
            navbar.style.top = '30px';
        } else {
            navbar.style.top = '90px';
        }
    });
}

function scrollToBooking() {
    document.getElementById('booking').scrollIntoView({ behavior: 'smooth' });
}

function makeCall() {
    window.location.href = 'tel:+201234567890';
}

// Date Picker
function initDatePicker() {
    flatpickr('#date', {
        dateFormat: 'Y-m-d',
        minDate: 'today',
        locale: currentLang === 'ar' ? {
            firstDayOfWeek: 6,
            weekdays: {
                shorthand: ['أحد', 'اثن', 'ثلاث', 'أربع', 'خميس', 'جمعة', 'سبط'],
                longhand: ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت']
            }
        } : 'default',
        onChange: function (selectedDates, dateStr) {
            if (dateStr) {
                loadTimeSlots(dateStr);
            }
        }
    });
}

// Form Handling
function initForm() {
    const form = document.getElementById('bookingForm');
    form.addEventListener('submit', handleBooking);
}

async function handleBooking(e) {
    e.preventDefault();

    const formData = {
        name: document.getElementById('name').value,
        phone: document.getElementById('phone').value,
        address: document.getElementById('address').value,
        acType: document.getElementById('acType').value,
        date: document.getElementById('date').value,
        time: document.getElementById('time').value
    };

    const submitBtn = document.getElementById('submitBtn');
    const btnText = submitBtn.querySelector('.btn-text');
    const loading = submitBtn.querySelector('.loading');

    // Show loading
    btnText.style.display = 'none';
    loading.classList.add('active');
    submitBtn.disabled = true;

    try {
        const response = await fetch('http://localhost:3000/api/bookings', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });

        if (response.ok) {
            showSuccess();
            form.reset();
            document.getElementById('time').innerHTML = '<option value="">اختر الوقت المتاح</option>';
        } else {
            throw new Error('Booking failed');
        }
    } catch (error) {
        alert('حدث خطأ في الحجز، حاول مرة أخرى');
    } finally {
        btnText.style.display = 'inline-block';
        loading.classList.remove('active');
        submitBtn.disabled = false;
    }
}

function showSuccess() {
    const successMsg = document.getElementById('successMessage');
    successMsg.classList.remove('hidden');
    setTimeout(() => {
        successMsg.classList.add('hidden');
    }, 5000);
}

// Time Slots
async function loadTimeSlots(date = null) {
    try {
        const url = date
            ? `http://localhost:3000/api/slots?date=${date}`
            : 'http://localhost:3000/api/slots';

        const response = await fetch(url);
        const slots = await response.json();

        const timeSelect = document.getElementById('time');
        timeSelect.innerHTML = '<option value="">اختر الوقت المتاح</option>';

        slots.forEach(slot => {
            if (slot.isAvailable) {
                const option = document.createElement('option');
                option.value = slot.time;
                option.textContent = `${slot.time} ✅`;
                timeSelect.appendChild(option);
            }
        });
    } catch (error) {
        console.error('Error loading slots:', error);
    }
}

// Offers
async function loadOffers() {
    try {
        const response = await fetch('http://localhost:3000/api/products');
        const offers = await response.json();

        const offersGrid = document.getElementById('offersGrid');
        offersGrid.innerHTML = '';

        offers.forEach(offer => {
            const offerCard = document.createElement('div');
            offerCard.className = 'offer-card';
            offerCard.innerHTML = `
                <img src="${offer.image || 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=400'}" 
                     alt="${offer.title}" class="offer-image">
                <div class="offer-content">
                    <h3>${offer.title}</h3>
                    <div class="offer-price">${offer.price} جنيه</div>
                    <p>${offer.description}</p>
                </div>
            `;
            offersGrid.appendChild(offerCard);
        });
    } catch (error) {
        console.error('Error loading offers:', error);
    }
}