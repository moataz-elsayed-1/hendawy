const mongoose = require('mongoose');

const timeSlotSchema = new mongoose.Schema({
    date: { type: String, required: true },
    time: { type: String, required: true },
    isAvailable: { type: Boolean, default: true }
});

module.exports = mongoose.model('TimeSlot', timeSlotSchema);