const Booking = require('../models/Booking');
const TimeSlot = require('../models/TimeSlot');

exports.createBooking = async (req, res) => {
    try {
        const { date, time } = req.body;

        // Check if slot is available
        const slot = await TimeSlot.findOne({ date, time });
        if (!slot || !slot.isAvailable) {
            return res.status(400).json({ error: 'الوقت غير متاح' });
        }

        // Create booking
        const booking = new Booking(req.body);
        await booking.save();

        // Mark slot as unavailable
        slot.isAvailable = false;
        await slot.save();

        res.status(201).json({
            message: 'تم الحجز بنجاح',
            booking: booking
        });
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

exports.getBookings = async (req, res) => {
    try {
        const bookings = await Booking.find().sort({ createdAt: -1 });
        res.json(bookings);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.updateBooking = async (req, res) => {
    try {
        const { id } = req.params;
        const { status } = req.body;

        const booking = await Booking.findById(id);
        if (!booking) {
            return res.status(404).json({ error: 'الحجز غير موجود' });
        }

        // If cancelled, make slot available again
        if (status === 'Cancelled' && booking.status !== 'Cancelled') {
            const slot = await TimeSlot.findOne({
                date: booking.date,
                time: booking.time
            });
            if (slot) {
                slot.isAvailable = true;
                await slot.save();
            }
        }

        booking.status = status;
        await booking.save();

        res.json(booking);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};