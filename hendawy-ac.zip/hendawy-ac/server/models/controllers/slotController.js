const TimeSlot = require('../models/TimeSlot');

exports.getSlots = async (req, res) => {
    try {
        const { date } = req.query;
        const filter = date ? { date } : {};
        const slots = await TimeSlot.find(filter);
        res.json(slots);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.createSlot = async (req, res) => {
    try {
        const slots = req.body;
        const savedSlots = await TimeSlot.insertMany(slots);
        res.status(201).json(savedSlots);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

exports.updateSlot = async (req, res) => {
    try {
        const { id } = req.params;
        const slot = await TimeSlot.findByIdAndUpdate(id, req.body, { new: true });
        res.json(slot);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};