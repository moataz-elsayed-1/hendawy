const express = require('express');
const bookingController = require('../controllers/bookingController');
const router = express.Router();

router.post('/', bookingController.createBooking);
router.get('/', bookingController.getBookings);
router.patch('/:id', bookingController.updateBooking);

module.exports = router;