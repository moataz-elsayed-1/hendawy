const express = require('express');
const productController = require('../controllers/productController');
const upload = require('../server'); // Multer instance
const router = express.Router();

router.get('/', productController.getProducts);
router.post('/', upload.single('image'), productController.createProduct);
router.patch('/:id', upload.single('image'), productController.updateProduct);
router.delete('/:id', productController.deleteProduct);

module.exports = router;