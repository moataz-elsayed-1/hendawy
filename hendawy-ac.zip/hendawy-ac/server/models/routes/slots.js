const express = require('express');
const slotController = require('../controllers/slotController');
const router = express.Router();

router.get('/', slotController.getSlots);
router.post('/', slotController.createSlot);
router.patch('/:id', slotController.updateSlot);

module.exports = router;