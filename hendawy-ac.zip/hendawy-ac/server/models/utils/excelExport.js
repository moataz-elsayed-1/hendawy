// Excel Export Route
const Booking = require('./models/Booking');
const excelExport = require('./utils/excelExport');

app.get('/api/export', async (req, res) => {
    try {
        const bookings = await Booking.find().sort({ createdAt: -1 });
        const excelBuffer = excelExport.exportBookingsToExcel(bookings);

        res.set({
            'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'Content-Disposition': 'attachment; filename=bookings.xlsx'
        });
        res.send(excelBuffer);
    } catch (error) {
        res.status(500).json({ error: 'خطأ في تصدير الملف' });
    }
});


const XLSX = require('xlsx');

exports.exportBookingsToExcel = (bookings) => {
    const ws = XLSX.utils.json_to_sheet(bookings.map(b => ({
        'الاسم': b.name,
        'الهاتف': b.phone,
        'العنوان': b.address,
        'نوع التكييف': b.acType,
        'التاريخ': b.date,
        'الوقت': b.time,
        'الحالة': b.status,
        'تاريخ الحجز': new Date(b.createdAt).toLocaleDateString('ar-EG')
    })));

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'الحجوزات');

    return XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
};