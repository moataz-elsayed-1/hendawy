const mongoose = require('mongoose');
const TimeSlot = require('./models/TimeSlot');
const Product = require('./models/Product');

mongoose.connect('mongodb://localhost:27017/hendawy');

async function seedData() {
    // Seed Time Slots for next 7 days
    const times = ['09:00', '11:00', '14:00', '16:00', '18:00'];
    const slots = [];

    for (let i = 0; i < 7; i++) {
        const date = new Date();
        date.setDate(date.getDate() + i);
        const dateStr = date.toISOString().split('T')[0];

        times.forEach(time => {
            slots.push({ date: dateStr, time, isAvailable: true });
        });
    }

    await TimeSlot.deleteMany({});
    await TimeSlot.insertMany(slots);
    console.log('✅ Added time slots');

    // Seed Products
    const products = [
        {
            title: 'صيانة شاملة سبليت',
            price: 250,
            image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=400',
            description: 'صيانة شاملة للتكييفات السبليت'
        },
        {
            title: 'تركيب تكييف جديد',
            price: 1200,
            image: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=400',
            description: 'تركيب تكييف جديد بضمان سنة'
        },
        {
            title: 'كشف أعطال',
            price: 100,
            image: 'https://images.unsplash.com/photo-1558494949-ef0d38d3f48a?w=400',
            description: 'زيارة كشف أعطال مجانية مع الصيانة'
        }
    ];

    await Product.deleteMany({});
    await Product.insertMany(products);
    console.log('✅ Added products');

    mongoose.connection.close();
}

seedData();